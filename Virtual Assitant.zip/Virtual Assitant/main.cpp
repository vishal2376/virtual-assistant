//------------------------Header files--------------------------------//
#include<iostream>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<windows.h>

using namespace std;

//-------------------------global variables--------------------//
string user,m_word,s_word;             //----------user-----main word-------simple word-------//
int pos,l_pos;                         //-------------position-----last position-------//




//------------------FUNCTION PROTOTYPES----------------------//

void intro();
void training();
void open_file(string);
void play_music(string);
void typing(string);
void repeat();
void help();


//-------------All possible intents---------//
//string hello


//--------------------Main Function---------------------------//
int main(){

intro();    //introduce itself


system("cls");
cout<<"\n\t";
typing("How Can I help you ? (type 'help' to get help)");

repeat();  //repeat the input from user


return 0;
}


//-----------------------------Repeat function-------------------------//
void repeat()
{
cout<<" \nType Here  ---> ";

getline(cin,user);   // get command from user

pos=user.find(" "); //set position to find the main command
m_word=user.substr(0,pos);
l_pos=user.find('\0');
s_word=user.substr(pos+1,l_pos);
//-----------check conditions--------------//
   if (m_word=="open"){
     //     open_file(s_word);
           }

   else if (m_word=="play"){
          play_music(s_word);

} else
   {
    typing("Sorry vishal,Unknown command.....");
    system("sorry.vbs");
     repeat();
   }
}


//--------------------------------------Typing function-------------------------------//
void typing(string msg)
{
    int i;
    if (msg != "Hello Vishal")
        cout<<"\n---> ";
    for(i = 0 ; msg[i] != '\0'; i++){
    cout<<msg[i];
    Sleep(50);
    }
}


//-----------------------Introduction function----------------------------//
void intro()
{

    for(int i=0;i<=100;i++)
    {
        system("cls");
     cout<<"\n\n\n\n\n\t\t\t\t\t\tLoading .....  ";
      cout<<i<<"%";
      Sleep(1+i);
    }
    cout<<"\n\n\t\t\t\t";
    typing("Hydron is Connected....");
    Sleep(200);
    system("cls");
    cout<<"\n\n\n\n\n\n\t\t\t\t\t\t";
    typing("Hello Vishal");  //Give a welcome message to user
    cout<<"\n";
    system("welcome.vbs");


}



//-----------------------------Function to open the files and folders------------------------//
void open_file(string open_fname)
{
 if (open_fname=="aircrack")
  {

       system("opening.vbs");
       typing("Opening the file "+open_fname);
       system("start Vishal\Hackers_Lab\Hacking_Tools\aircrack_ng\bin\Aircrack-ngGUI.exe");

  }

}

//-----------------------------Function to play music----------------------//
void play_music(string play_fname)
{
    system("cls");
 if (play_fname=="dilbar")
  {

       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/dilbar.mp3");
       repeat();

  }
   else if (play_fname=="faded")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Alan_Walker_Fade.mp3");
       repeat();
    }
   else if (play_fname=="trending nakhra")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/trending-nakhra.mp3");
       repeat();
    }
   else if (play_fname=="badfella")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Badfella_Sidhu_Moose_Wala.mp3");
       repeat();
    }
   else if (play_fname=="bangtown")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Bangtown.mp3");
       repeat();
    }
   else if (play_fname=="bom diggy")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Bom-Diggy-(Mr-Jatt.com).mp3");
       repeat();
    }
   else if (play_fname=="boss")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Boss.mp3");
       repeat();
    }
   else if (play_fname=="closer")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Closer.mp3");
       repeat();
    }
   else if (play_fname=="dark love")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Dark-Love.mp3");
       repeat();
    }
   else if (play_fname=="dekhte dekhte")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Dekhte-Dekhte-(Mr-Jatt.com).mp3");
       repeat();
    }
   else if (play_fname=="el bano")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/EL_BANO.mp3");
       repeat();
    }
   else if (play_fname=="dont let me down")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Dont-let-me-down.mp3");
       repeat();
    }
   else if (play_fname=="famous")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Famous.mp3");
       repeat();
    }
   else if (play_fname=="guerrilla war")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Guerrilla-War(RaagJatt.com).mp3");
       repeat();
    }
   else if (play_fname=="haryana roadways")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Haryana-Roadways.mp3");
       repeat();
    }
   else if (play_fname=="issa jatt")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Issa-Jatt.mp3");
       repeat();
    }
   else if (play_fname=="mi gente")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/mi-gente.mp3");
       repeat();
    }
   else if (play_fname=="jakcetan lightan waliyan")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Jakcetan_Lightan_Waliyan_Amrit_Maan_53979bb8931a8ddad40267c660f65b74_128.mp3");
       repeat();
    }
   else if (play_fname=="jatt da muqabala")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Jatt-Da-Muqabla");
       repeat();
    }
   else if (play_fname=="milan")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/milan.mp3");
       repeat();
    }
   else if (play_fname=="taki taki")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/muzmo_ru_DJ_Snake_-_Taki_Taki_feat_Selena_Gomez_Ozuna_Cardi_B_b128f0d210.mp3");
       repeat();
    }
   else if (play_fname=="x")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/muzmo_ru_Nicky_Jam_feat_J_Balvin_-_X_Equis_54237794.mp3");
       repeat();
    }
   else if (play_fname=="alone")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/muzmo_ru_marshmello_-_Alone_48262456.mp3");
       repeat();
    }
   else if (play_fname=="cheap thrills")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/muzmo_ru_Sia_feat_Sean_Paul_-_Cheap_Thrills_35325459.com.mp3");
       repeat();
    }
   else if (play_fname=="rang gora")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Rang-Gora-(Mr-Jatt.com).mp3");
       repeat();
    }
   else if (play_fname=="nickle current")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Nikle_Currant_Jassi_Gill_5325f23ec9a034b6d0bc84e17054d030_48.com).mp3");
       repeat();
    }
   else if (play_fname=="pariyaan toh sohni")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Pariyaan-Toh-Sohni-(Mr-Jatt.com)).mp3");
       repeat();
    }
   else if (play_fname=="peg di waashna")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Peg-Di-Waashna-(Mr-Jatt.com).mp3");
       repeat();
    }
   else if (play_fname=="sakhiyan")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Sakhiyan_Maninder_Buttar_50f01534794245e5c8f0b79e152189e1_128.mp3");
       repeat();
    }
   else if (play_fname=="shape of you")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Shape-Of-You-Ed-Sheeran(MalluMusic.Net).mp3");
       repeat();
    }
   else if (play_fname=="subeme la radio")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Subeme_La_Radio_Enrique_Iglesias_128Kbps(Gomirchi.in).mp3");
       repeat();
    }
   else if (play_fname=="tochna")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/tochna.mp3");
       repeat();
    }
   else if (play_fname=="salute")
    {
       system("playing.vbs");
       typing("Playing the song "+play_fname);
       system("start My_beat/Salute-(Mr-Jatt.com).mp3");
       repeat();
    }

    else{
        typing("Error : There is no such file here...");
        repeat();
    }







}//end the function play_music


